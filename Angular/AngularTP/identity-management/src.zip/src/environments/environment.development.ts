export const environment = {
    usersApiUrl: 'api/users',
};
