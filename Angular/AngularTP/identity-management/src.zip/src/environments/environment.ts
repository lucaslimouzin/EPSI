import {HttpClient, HttpHeaders} from "@angular/common/http";
import {UserLdap} from "../app/models/user-ldap";

export const environment = {
    production: false,
    usersApiUrl: 'api/users',
};

