module.exports = {
  spec: 'tests/**/*.spec.js',
};
