import java.util.Scanner;

/**
 * Exercice : Nombre Pair ou Impair
 * 
 * Écrivez un programme Java qui demande à l'utilisateur d'entrer un nombre
 * entier, puis détermine si ce nombre est pair ou impair. Affichez le résultat
 * correspondant.
 */

public class NombrePairImpair {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Entrez un nombre entier : ");
        int nombre = scanner.nextInt();

        if (nombre % 2 == 0) {
            System.out.println(nombre + " est un nombre pair.");
        } else {
            System.out.println(nombre + " est un nombre impair.");
        }

        // Ferme le scanner pour libérer les ressources
        scanner.close();
    }
}