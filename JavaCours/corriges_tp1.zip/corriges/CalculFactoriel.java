import java.util.Scanner;

public class CalculFactoriel {

    // Méthode récursive pour calculer le factoriel 
    public static long calculerFactorielRecursif(int n) {
        if (n == 0 || n == 1) {
            return 1;
        } else {
            return n * calculerFactorielRecursif(n - 1);
        }
    }

    // Méthode non récursive pour calculer le factoriel
    public static long calculerFactorielIteratif(int n) {
        long resultat = 1;
        for (int i = 1; i <= n; i++) {
            resultat *= i;
        }
        return resultat;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Entrez un nombre entier positif : ");
        int nombre = scanner.nextInt();

        if (nombre < 0) {
            System.out.println("Le nombre doit être positif.");
        } else {
            long factorielRecursif = calculerFactorielRecursif(nombre);
            long factorielIteratif = calculerFactorielIteratif(nombre);

            System.out.println("Factoriel (récursif) de " + nombre + " : " + factorielRecursif);
            System.out.println("Factoriel (itératif) de " + nombre + " : " + factorielIteratif);
        }

        scanner.close();
    }
}
