import java.util.Scanner;

public class Palindrome {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Entrez une chaîne de caractères : ");
        String chaine = scanner.nextLine();

        if (estPalindrome(chaine)) {
            System.out.println(chaine + " est un palindrome.");
        } else {
            System.out.println(chaine + " n'est pas un palindrome.");
        }
        
        scanner.close();
    }

    // Méthode pour vérifier si une chaîne de caractères est un palindrome
    public static boolean estPalindrome(String chaine) {
        // Supprimez les espaces et convertissez la chaîne en minuscules pour une comparaison insensible à la casse
        chaine = chaine.replace(" ", "").toLowerCase();

        int longueur = chaine.length();

        for (int i = 0; i < longueur / 2; i++) {
            if (chaine.charAt(i) != chaine.charAt(longueur - 1 - i)) {
                return false;
            }
        }

        return true;
    }
}
