import java.util.Scanner;

public class PlusLongMot {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Entrez une phrase : ");
        String phrase = scanner.nextLine();

        String[] mots = phrase.split(" ");
        String[] motsLesPlusLongs = trouverMotsLesPlusLongs(mots);

        System.out.print("Le(s) mot(s) le(s) plus long(s) dans la phrase est(sont) : ");
        for (int i = 0; i < motsLesPlusLongs.length; i++) {
            System.out.print("\"" + motsLesPlusLongs[i] + "\"");
            if (i < motsLesPlusLongs.length - 1) {
                System.out.print(", ");
            }
        }

        scanner.close();
    }

    // Méthode pour trouver le(s) mot(s) le(s) plus long(s)
    public static String[] trouverMotsLesPlusLongs(String[] mots) {
        int longueurMax = 0;
        for (String mot : mots) {
            int longueurMot = mot.replaceAll("[^a-zA-Z]", "").length();
            if (longueurMot > longueurMax) {
                longueurMax = longueurMot;
            }
        }

        int nombreDeMotsLesPlusLongs = 0;
        for (String mot : mots) {
            int longueurMot = mot.replaceAll("[^a-zA-Z]", "").length();
            if (longueurMot == longueurMax) {
                nombreDeMotsLesPlusLongs++;
            }
        }

        String[] motsLesPlusLongs = new String[nombreDeMotsLesPlusLongs];
        int index = 0;
        for (String mot : mots) {
            int longueurMot = mot.replaceAll("[^a-zA-Z]", "").length();
            if (longueurMot == longueurMax) {
                motsLesPlusLongs[index] = mot;
                index++;
            }
        }

        return motsLesPlusLongs;
    }
}
