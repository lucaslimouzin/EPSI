import java.util.Scanner;

public class CalculSomme {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Demander à l'utilisateur d'entrer un nombre entier N
        System.out.print("Entrez un nombre entier N : ");
        int N = scanner.nextInt();

        // Calculer la somme des nombres de 1 à N
        int somme = 0;
        for (int i = 1; i <= N; i++) {
            somme += i;
        }

        // Afficher le résultat
        System.out.println("La somme des nombres de 1 à " + N + " est : " + somme);

        // Fermer le scanner
        scanner.close();
    }
}