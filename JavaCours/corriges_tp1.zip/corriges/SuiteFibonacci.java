import java.util.Scanner;

public class SuiteFibonacci {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Combien de termes de la suite de Fibonacci voulez-vous générer ? ");
        int n = scanner.nextInt();

        int premierTerme = 0, deuxiemeTerme = 1;

        System.out.print("Les " + n + " premiers termes de la suite de Fibonacci sont :\n" + premierTerme + ", " + deuxiemeTerme);

        int i = 2;
        while (i < n) {
            int suivant = premierTerme + deuxiemeTerme;
            System.out.print(", " + suivant);
            premierTerme = deuxiemeTerme;
            deuxiemeTerme = suivant;
            i++;
        }
        
        System.out.println();

        scanner.close();
    }
}
