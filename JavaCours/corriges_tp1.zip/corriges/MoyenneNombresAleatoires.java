import java.util.Scanner;

public class MoyenneNombresAleatoires {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Demander à l'utilisateur de saisir un nombre entier N entre 3 et 20
        int N;
        do {
            System.out.print("Entrez un nombre entier N entre 3 et 20 : ");
            N = scanner.nextInt();
        } while (N < 3 || N > 20);

        // Créer un tableau pour stocker les nombres aléatoires
        int[] nombresAleatoires = new int[N];

        // Remplir le tableau avec N entiers aléatoires entre 0 et 100
        for (int i = 0; i < N; i++) {
            nombresAleatoires[i] = (int) (Math.random() * 101); // Générer un nombre aléatoire entre 0 et 100
        }

        // Calculer la somme des nombres
        int somme = 0;
        for (int nombre : nombresAleatoires) {
            somme += nombre;
        }

        // Calculer la moyenne
        double moyenne = (double) somme / N;

        // Afficher la moyenne calculée
        System.out.println("Les " + N + " nombres aléatoires sont : ");
        for (int nombre : nombresAleatoires) {
            System.out.print(nombre + " ");
        }
        System.out.println("\nLa moyenne des nombres aléatoires est : " + moyenne);

        // Fermer le scanner
        scanner.close();
    }
}