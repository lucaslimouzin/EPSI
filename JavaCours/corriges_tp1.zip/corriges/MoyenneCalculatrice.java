import java.util.Scanner;

public class MoyenneCalculatrice {
    
    public static void main(String[] args) {
        // Créer un objet Scanner pour lire l'entrée de l'utilisateur
        Scanner scanner = new Scanner(System.in);
        
        // Demander à l'utilisateur de saisir trois nombres
        System.out.println("Entrez le premier nombre : ");
        double nombre1 = scanner.nextDouble();
        
        System.out.println("Entrez le deuxième nombre : ");
        double nombre2 = scanner.nextDouble();
        
        System.out.println("Entrez le troisième nombre : ");
        double nombre3 = scanner.nextDouble();
        
        // Calculer la moyenne
        double moyenne = (nombre1 + nombre2 + nombre3) / 3;
        
        // Afficher la moyenne
        System.out.println("La moyenne des trois nombres est : " + moyenne);
        
        // Fermer le scanner
        scanner.close();
    }
}