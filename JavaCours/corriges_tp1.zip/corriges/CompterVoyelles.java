import java.util.Scanner;

public class CompterVoyelles {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Entrez une phrase : ");
        String phrase = scanner.nextLine().toLowerCase(); // Convertir la phrase en minuscules pour compter toutes les voyelles.

        int compteurVoyelles = 0;

        for (int i = 0; i < phrase.length(); i++) {
            char caractere = phrase.charAt(i);
            if (caractere == 'a' || caractere == 'e' || caractere == 'i' 
                || caractere == 'o' || caractere == 'u' || caractere == 'y') {
                compteurVoyelles++;
            }
        }

        System.out.println("La phrase contient " + compteurVoyelles + " voyelles.");
        scanner.close();
    }
}
